import 'dart:math';
class DNum {
  num n1;
  num n2;

  DNum([num? n1, num? n2]):
        n1 = n1 ?? -1,
        n2 = n2 ?? 1;


}