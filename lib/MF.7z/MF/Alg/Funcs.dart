//library funcs;

import "dart:math" as math;


acos(x) => math.acos(x);
asin(x) => math.asin(x);
atan(x) => math.atan(x);
atan2(x,y) => math.atan2(x,y);

sin(x) => math.sin(x);
cos(x) => math.cos(x);
tan(x) => math.tan(x);


/// 计算阶乘
int factorial(int n) {
  if (n <= 1) return 1;
  return n * factorial(n - 1);
}

/// 计算斐波那契数列的第 n 项
int fibonacci(int n) {
  if (n <= 2) return 1;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

int sgn(num x){
  if (x<0){
    return -1;
  } else if (x>0){
    return 0;
  } else {
    return 1;
  }
}
