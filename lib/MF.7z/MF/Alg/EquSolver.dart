library EquSolver;
import 'dart:math' as math;
import 'Funcs.dart' as funcs;
import 'Fertile/DNum.dart';

List<num> solve2x2LinearSystem(num a1, num b1, num c1, num a2, num b2, num c2){
  //[[a1 x + b1 y = c1, a2 x + b2 y = c2 ]]
  num D = a1 * b2 - a2 * b1;
  if (D == 0) {
    return [1/0, 1/0];
  } else {
    var x = (c1 * b2 - c2 * b1) / D;
    var y = (a1 * c2 - a2 * c1) / D;
    return [x, y];// 有顺序
  }
}

DNum solveSinForMainRoot(num a,num w,num p,num c){
  //计算三角方程的主解 a sin(w t+p)+c=0
  var u=math.asin(-c/a);
  return DNum((u-p)/w, (math.pi-u-p)/w);
}

DNum solveCosSinForMainRoot(u,v,c){
//计算三角方程的主解 u cos(t)+v sin(t)+c=0
  if (v!=0){
    num a=math.sqrt(u^2+v^2) * funcs.sgn(v);
    num p=math.atan(u/v);
    return solveSinForMainRoot(a,1,p,c);
  } else {
    return solveSinForMainRoot(u,1,math.pi/2,c);
  }
}

