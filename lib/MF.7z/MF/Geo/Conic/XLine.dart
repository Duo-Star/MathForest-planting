import 'dart:math';
import '../Linear/Vec.dart';
import '../Fertile/DPoint.dart';
import '../../Alg/Fertile/DNum.dart';

class XLine {
  final Vec p;
  final Vec u;
  final Vec v;

  //conic2: p + t*u + ( 1/t )*v
  XLine([Vec? p, Vec? u, Vec? v]):
        p = p ?? Vec(),
        u = u ?? Vec(1,  1),
        v = v ?? Vec(1, -1);


}