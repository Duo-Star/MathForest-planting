import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';

import '../Linear/Vec.dart';
import '../Conic/Circle.dart';
import '../Conic/Conic0.dart';
import '../Conic/Conic1.dart';
import '../Conic/Conic2.dart';
import '../Fertile/DPoint.dart';


class Monxiv {
   Vec p = Vec();
   num lam = 10;
   final Paint defaultPaint = Paint()
     ..color = Colors.amber
     ..style = PaintingStyle.stroke
     ..strokeWidth = 2.0;

  Vec C2S(Vec c){
    return Vec(c.x * lam + p.x,-c.y * lam + p.y);
  }
  Vec S2C(Vec s){
    return Vec((s.x-p.x) / lam, -(s.x-p.x) / lam);
  }
  void reset(){
    p = Vec();
    lam = 10;
  }

   bool drawCircle(Circle circle, Canvas canvas, {Paint? paint}) {
     final Paint usedPaint = paint ?? defaultPaint;
     canvas.drawCircle(
         C2S(circle.p).offset,
         circle.r.toDouble(),
         usedPaint
     );
     return true;
   }

   bool drawPoint(Vec p, Canvas canvas, {Paint? paint}) {
     final Paint usedPaint = paint ?? defaultPaint;
     canvas.drawCircle(C2S(p).offset, 3, usedPaint);
     return true;
   }

   bool drawDPoint(DPoint dP, Canvas canvas, {Paint? paint}) {
     drawPoint(dP.p1, canvas);
     drawPoint(dP.p2, canvas);
     return true;
   }


   bool drawConic0(Conic0 c0, Canvas canvas, {Paint? paint}) {
     final Paint usedPaint = paint ?? defaultPaint;
     Path p = Path();
     Vec initVec = C2S(c0.indexPoint(0));
     p.moveTo(initVec.x.toDouble(), initVec.y.toDouble());
     for (double theta = 0.1; theta <= 2 * pi; theta += 0.1) {
       Vec nowVec =C2S(c0.indexPoint(theta));
       p.lineTo(nowVec.x.toDouble(), nowVec.y.toDouble());
     }
     p.close();
     canvas.drawPath(p, usedPaint);
     return true;
   }

   bool drawConic2(Conic2 c2, Canvas canvas, {Paint? paint}) {
     final Paint usedPaint = paint ?? defaultPaint;
     Path p1 = Path();
     Vec initVec1 = C2S(c2.indexPoint(-5));
     p1.moveTo(initVec1.x.toDouble(), initVec1.y.toDouble());
     for (double t = -5; t <= 0; t += 0.1) {
       Vec nowVec =C2S(c2.indexPoint(t));
       p1.lineTo(nowVec.x.toDouble(), nowVec.y.toDouble());
     }
     canvas.drawPath(p1, usedPaint);

     Path p2 = Path();
     Vec initVec2 = C2S(c2.indexPoint(0.1));
     p1.moveTo(initVec2.x.toDouble(), initVec2.y.toDouble());
     for (double t = 0.1; t <= 5; t += 0.1) {
       Vec nowVec =C2S(c2.indexPoint(t));
       p2.lineTo(nowVec.x.toDouble(), nowVec.y.toDouble());
     }
     canvas.drawPath(p2, usedPaint);

     return true;
   }


}