class Angle {
  final num theta;
  final num phi;

  Angle(num theta, [num phi = 0.0])
      : theta = theta,
        phi = phi;

}