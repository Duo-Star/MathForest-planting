//Triangle
import 'dart:math';
import 'Vec.dart';

class Triangle{
  Vec a;
  Vec b;
  Vec c;

  Triangle([Vec? a, Vec? b, Vec? c]): //三个点
  a = a ?? Vec.i(),
  b = b ?? Vec.j(),
  c = c ?? Vec.k();

  Vec get iO {
    return Vec();
  }

  Vec get oO {
    return Vec();
  }

  Vec get hO {
    return Vec();
  }

  Vec get iO {
    return Vec();
  }

  
}